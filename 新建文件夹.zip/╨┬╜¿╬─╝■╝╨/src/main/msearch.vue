<template>
    <div id="search-input" class="search-input">
            
                <i class="search-icon iconfont"></i>
                <p>搜索商品</p>
           
        </div>
</template>
<script>
export default {};
</script>
<style scoped>
.search-input {
  background-color: #f8f8f8;
  padding: 0.325rem 0.5rem;
  position: relative;
}

.search-icon {
  bottom: 0;
  color: #999;
  left: 1.075rem;
  line-height: 2.15rem;
  position: absolute;
  top: 0;
}
.search-input p {
  background: #fff;
  border: none;
  border-radius: 1.5rem;
  box-sizing: border-box;
  color: #999;
  font-size: 13px;
  height: 1.5rem;
  line-height: 1.5rem;
  padding-left: 1.65rem;
  width: 100%;
}
</style>


