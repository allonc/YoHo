<template>
    <div>
        <div style="background-image:url(//img11.static.yhbimg.com/yhb-img01/2016/11/24/09/011b38b2de8ff682ebd5ea2d019f4e20ee.jpg?imageView2/2/w/640/h/26/q/60)" class="divide-image"></div>
        <div data-id="37473">
            <div class="banner-list">
        <a href="https://activity.yoho.cn/feature/3217.html?share_id=5883&amp;title=满额最高享7.5折/BOY" id="37473" name="一张图片" rel="nofollow">
            <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/17/017d288a02e6852755df1e98882a172bcc.jpg?imageView2/3/w/640/h/200/q/60" alt="活动图片">
        </a>
    </div>
    </div>
    <div style="background-image:url(//img11.static.yhbimg.com/yhb-img01/2016/11/24/09/015e57e3cc0de6512110cc4a5a2bd97e56.jpg?imageView2/2/w/640/h/26/q/60)" class="divide-image"></div>
    <div data-id="36611">
            <div class="banner-list">
        <a href="https://list.m.yohobuy.com/sale/special/gd1.html?specialsale_id=6" id="36611" name="一张图片" rel="nofollow">
            <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/17/0176db9b1d2d8fea6f7e1095abf1b70699.jpg?imageView2/3/w/640/h/200/q/60" alt="活动图片">
        </a>
    </div>
    </div>
    </div>
</template>
<script>
export default {};
</script>
<style>
</style>
