<template>
<div>
    <xheader />
    <xbanner />
    <xwrapper />
    <xspace />
    <xhotList />
    <xbanner2 />
    <xhotBrand />
    <xnewUser />
    <xhotsingle />
    <xgoodslist />
    <xfooter />
    <xfooterTab />
</div>
</template>
<script>
import xheader from './xheader.vue';
import xsearch from './xsearch.vue';
import xfooter from './xfooter.vue';
import xgallery from './xgallery.vue';
import xbanner from './xbanner.vue';
import xwrapper from './xwrapper.vue';
import xspace from './xspace.vue';
import xhotList from './xhotList.vue';
import xbanner2 from './xbanner2.vue';
import xhotBrand from './xhotBrand.vue';
import xnewUser from './xnewUser.vue';
import xhotsingle from './xhotSingle.vue';
import xfooterTab from './xfooterTab.vue';
import xgoodslist from './xgoodslist.vue';

export default {
  components: {
    xheader,
    xsearch,
    xfooter,
    xgallery,
    xbanner,
    xwrapper,
    xspace,
    xhotList,
    xbanner2,
    xhotBrand,
    xnewUser,
    xhotsingle,
    xfooterTab,
    xgoodslist
  }
}
</script>
<style>

</style>
