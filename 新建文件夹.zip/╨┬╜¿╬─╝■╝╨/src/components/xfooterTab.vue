<template>
    <div class="footer-tab">
    <a class="tab-item current boys" href="//m.yohobuy.com/?go=1">
        <p class="iconfont tab-icon"></p>
        <p class="tab-name">首页</p>
    </a>
    <a class="tab-item " href="//m.yohobuy.com/cate">
        <p class="iconfont tab-icon"></p>
        <p class="tab-name">分类</p>
    </a>
    <a class="tab-item " id="guangUrl" href="//m.yohobuy.com/guang">
        <p class="iconfont tab-icon"></p>
        <p class="tab-name">逛</p>
    </a>
    <a class="tab-item " href="//m.yohobuy.com/cart/index/index" rel="nofollow">
        <p class="iconfont tab-icon"></p>
        <p class="tab-name">购物车</p>
    </a>
    <a class="tab-item " href="//m.yohobuy.com/home" rel="nofollow">
        <p class="iconfont tab-icon"></p>
        <p class="tab-name">我的</p>
    </a>
</div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>

