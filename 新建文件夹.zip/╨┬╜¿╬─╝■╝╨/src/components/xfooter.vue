<template>
<div>
    ​<footer id="yoho-footer" class="yoho-footer" style="display: block; margin-bottom: 50px;">
    <p class="op-row"><a href="/signin.html?refer=https://m.yohobuy.com/boys" rel="nofollow">登录</a><span class="sep-line">|</span><a href="/reg.html" rel="nofollow">注册</a>
        <span @click="backTop" class="back-to-top">
            回到顶部
            <i class="iconfont"></i>
        </span>
        </p><div class="float-top "></div>
    <p></p>
    <address class="copyright">
        CopyRight©2007-2018 南京新与力文化传播有限公司
    </address>
    </footer>
</div>
</template>
<script>
export default {
  data() {
    return {
      
    }
  },
  methods:{
      backTop(){
          document.documentElement.scrollTop = document.body.scrollTop = 0;
      }
  }
};
</script>
<style>

</style>
