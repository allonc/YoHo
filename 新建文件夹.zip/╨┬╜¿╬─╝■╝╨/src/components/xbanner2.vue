<template>
    <div data-id="36565">
        <div class="banner-center banner-center-swiper swiper-container">
    <ul class="banner-list swiper-wrapper clearfix" style="transform: translate3d(-1280px, 0px, 0px); transition-duration: 0ms;"><li class="swiper-slide swiper-slide-duplicate swiper-slide-next" data-swiper-slide-index="2" style="width: 320px;">
            <a href="https://list.m.yohobuy.com/?gender=1,3&amp;msort=3&amp;misort=26,27" id="36565" name="一张图片" rel="nofollow">
                <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/17/011c36c1754455ed5341386e4d6684a0fc.jpg?imageView2/3/w/640/h/200/q/60" alt="活动图片">
            </a>
        </li>
        <li class="swiper-slide" data-swiper-slide-index="0" style="width: 320px;">
            <a href="https://list.m.yohobuy.com/?gender=1,3&amp;msort=1&amp;misort=21" id="36565" name="一张图片" rel="nofollow">
                <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/17/0175eb787dfcfa49a9b1bdf779aad3db20.jpg?imageView2/3/w/640/h/200/q/60" alt="活动图片">
            </a>
        </li>
        <li class="swiper-slide" data-swiper-slide-index="1" style="width: 320px;">
            <a href="https://list.m.yohobuy.com/?gender=1,3&amp;msort=1&amp;misort=16" id="36565" name="一张图片" rel="nofollow">
                <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/17/018864b8d891281a3ce23434665a594998.jpg?imageView2/3/w/640/h/200/q/60" alt="活动图片">
            </a>
        </li>
        </ul>
    <div class="swiper-pagination" style="display:block">
        <div class="pagination-inner swiper-pagination-clickable swiper-pagination-bullets"><span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span><span class="swiper-pagination-bullet"></span><span class="swiper-pagination-bullet"></span></div>
    </div>
</div>
    </div>
</template>
<script>
import Swiper from "swiper";
import "../../node_modules/swiper/dist/css/swiper.css";
export default {
    data(){
        return{

        }
    },
    mounted() {
    var swiper = new Swiper(".swiper-container", {
      spaceBetween: 0,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
      }
    });
  }
    
}
</script>
<style>

</style>
