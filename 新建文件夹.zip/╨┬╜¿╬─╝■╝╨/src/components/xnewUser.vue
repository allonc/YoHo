<template>
    <div data-id="6302">
            <div class="banner-list">
        <a href="https://activity.yoho.cn/feature/135.html?share_id=2043&amp;title=新人礼遇" id="6302" name="一张图片" rel="nofollow">
            <img src="//img10.static.yhbimg.com/yhb-img01/2018/09/14/09/0167230098d1cc72ea4c282e7f6e08fce3.jpg?imageView2/3/w/640/h/200/q/60" alt="活动图片">
        </a>
    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>

