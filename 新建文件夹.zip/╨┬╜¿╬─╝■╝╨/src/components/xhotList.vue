<template>
    <div>
    <div class="hot-category">
        <div class="floor-header-more">
            <h2>热门品类</h2>
        </div>
        <ul class="category-list clearfix">
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci61.html">
                    <div class="img-box">
                        <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/13/017d841a5de650e0aa05241ca22a51f566.jpg?imageView2/2/w/140/h/140/q/60" alt="卫衣">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci72.html">
                    <div class="img-box">
                        <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/13/01b5400cc79e1a3387e571aa4a76363596.jpg?imageView2/2/w/140/h/140/q/60" alt="夹克">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci56">
                    <div class="img-box">
                        <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/13/01319a50d7e5f49406aac26a7d3605b77f.jpg?imageView2/2/w/140/h/140/q/60" alt="衬衫">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://list.m.yohobuy.com/?standard=918_5726&amp;title=板鞋/滑板鞋&amp;actiontype=0&amp;gender=1,3&amp;firstProductSkn=51861500">
                    <div class="img-box">
                        <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/13/0113ccd615812f79ced8d4f8877c10b784.jpg?imageView2/2/w/140/h/140/q/60" alt="板鞋/滑板鞋">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci107">
                    <div class="img-box">
                        <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/13/01c24f6b23c3336f84b17f9bcb08f523d5.jpg?imageView2/2/w/140/h/140/q/60" alt="休闲/运动鞋">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci119">
                    <div class="img-box">
                        <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/13/011de2e3081d9633bdb7f7aaa26cf70a17.jpg?imageView2/2/w/140/h/140/q/60" alt="靴子">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci92">
                    <div class="img-box">
                        <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/13/01dcbe6e52111d00ce427cea46e915c57b.jpg?imageView2/2/w/140/h/140/q/60" alt="牛仔裤">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci90">
                    <div class="img-box">
                        <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/13/01abb1d97b046b2fc544b13716994fe64a.jpg?imageView2/2/w/140/h/140/q/60" alt="休闲裤">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci136">
                    <div class="img-box">
                        <img src="//img10.static.yhbimg.com/yhb-img01/2018/10/15/13/01799aa7264a23cbeb15805ab99aa391dd.jpg?imageView2/2/w/140/h/140/q/60" alt="手拎包/单肩包">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci178">
                    <div class="img-box">
                        <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/13/0136265f11454fa2b1fe1615069c10cb6a.jpg?imageView2/2/w/140/h/140/q/60" alt="帽子">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci179">
                    <div class="img-box">
                        <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/13/0190a673c07304a08d131d02bb1a20dcc2.jpg?imageView2/2/w/140/h/140/q/60" alt="首饰">
                    </div>
                </a>
            </li>
            <li>
                <a href="https://m.yohobuy.com/list/gd1,3-ci180">
                    <div class="img-box">
                        <img src="//img11.static.yhbimg.com/yhb-img01/2018/10/15/13/01ad0b2ee36a9b0052355d17d445f5d3cd.jpg?imageView2/2/w/140/h/140/q/60" alt="袜子">
                    </div>
                </a>
            </li>
        </ul>
    </div>
    <div style="background-image:url(//img10.static.yhbimg.com/yhb-img01/2016/11/24/09/019af52e46fe602b54b3d395349984d252.jpg?imageView2/2/w/640/h/26/q/60)" class="divide-image"></div>
    </div>
</template>
<script>
export default {};
</script>
<style>
</style>
