<template>
    <div class="icons-wrapper" style="background-image:url(//img11.static.yhbimg.com/yhb-img01/2017/02/03/09/012861c7ab0b730fe5825bab664bd374b7.jpg?imageView2/2/w/640/h/360/q/60)">
    <ul class="icons-list clearfix">
        <li class="icons-item item-4"><a href="https://m.yohobuy.com/boys-new/ " class="imagebar"><img src="//img10.static.yhbimg.com/yhb-img01/2017/02/03/09/01ae835d5ae6d9502818daf351ad2db6cf.png?imageView2/2/w/98/h/98/q/60" alt=""></a><a href="https://m.yohobuy.com/boys-new/ " class="linkbar">新品到着</a></li>
        <li class="icons-item item-4"><a href="https://guang.m.yohobuy.com/?type=2&amp;name=搭配" class="imagebar"><img src="//img11.static.yhbimg.com/yhb-img01/2017/02/03/09/011004f5a04caaf9c18d7848049a75981e.png?imageView2/2/w/98/h/98/q/60" alt=""></a><a href="https://guang.m.yohobuy.com/?type=2&amp;name=搭配" class="linkbar">人气搭配</a></li>
        <li class="icons-item item-4"><a href="https://m.yohobuy.com/boys-sale/" class="imagebar"><img src="//img11.static.yhbimg.com/yhb-img01/2017/02/03/09/01d35157ab5942ea40b4f08a11c1680a17.png?imageView2/2/w/98/h/98/q/60" alt=""></a><a href="https://m.yohobuy.com/boys-sale/" class="linkbar">折扣专区</a></li>
        <li class="icons-item item-4"><a href="https://m.yohobuy.com/cate?gender=1,3" class="imagebar"><img src="//img10.static.yhbimg.com/yhb-img01/2017/02/03/09/01b097e06ac9fc78bbcc3d3e0dfbe01fcc.png?imageView2/2/w/98/h/98/q/60" alt=""></a><a href="https://m.yohobuy.com/cate?gender=1,3" class="linkbar">全部分类</a></li>
    </ul>
    </div>
    
</template>
<script>
export default {};
</script>
<style>
</style>
