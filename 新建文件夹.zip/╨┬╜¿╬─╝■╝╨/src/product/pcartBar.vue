<template>
    <div class="cart-bar" style="display: block;">
        <input type="hidden" id="remove-cart-count" value="1">
    <a class="new-foot-ico" href="//m.yohobuy.com/cart/index/index" rel="nofollow">
        <div class="num-incart iconfont">
            <span class="num-tag hide"></span>
            
        </div>
        <div class="tip">购物车</div>
    </a>
    <a class="new-foot-ico store" href="/shop/apportfolio-1294.html">
        <div class="iconfont"></div>
        <div class="tip">品牌店铺</div>
    </a>
    <a href="javascript:;" class="new-foot-ico fav like-btn-c">
        <div id="likeBtn" class="favorite iconfont "></div>
        <div class="tip opa">收藏</div>
    </a>
    <span class="btn-c">
        <a id="addtoCart" href="javascript:;" class="addto-cart add-to-cart-url">加入购物车</a>
    </span>
    <input type="hidden" id="limitCodeUrl" name="limitCodeUrl" value="">
    <input type="hidden" id="limitProductPay" name="limitProductPay" value="">
</div>

</template>
<script>
export default {
    
}
</script>
<style>

</style>

