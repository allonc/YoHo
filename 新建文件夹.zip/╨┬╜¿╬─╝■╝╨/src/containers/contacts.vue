<template>
    <div>
        <p>通讯录</p>
        <xfooter />
    </div>
</template>
<script>
import xfooter from '../components/xfooter.vue';
export default {
    data(){
        return{

        }
    },
    components:{
        xfooter
    }
}
</script>
<style>

</style>
