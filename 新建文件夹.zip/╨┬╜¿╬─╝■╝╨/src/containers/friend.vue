<template>
    <div>
        <p>朋友圈</p>
        <xfooter />
    </div>
</template>
<script>
import xfooter from '../components/xfooter.vue';
export default {
    data(){
        return{

        }
    },
    components:{
        xfooter
    }
}
</script>
<style>

</style>
