<template>
</template>
<script>
import xheader from '../components/xheader.vue';

export default {
    data(){
        return{

        }
    },
    components:{
        xheader,
        
    }
    
}
</script>
<style>

</style>
